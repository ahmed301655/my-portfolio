# Ahmed Fuad Saif Hunaish | Personal Portfolio

This is a bilingual personal portfolio website (Arabic & English) for Electrical Engineer Ahmed Fuad Saif Hunaish.

## Features:
- Arabic & English toggle without reload.
- Downloadable Arabic and English CVs.
- Responsive design (mobile-friendly).
- Project portfolio and contact section.

## How to Use:
1. Clone this repository or upload to GitHub.
2. Place your CV files as `cv-ar.pdf` (Arabic) and `cv-en.pdf` (English).
3. Enable GitHub Pages from the repository settings under the "Pages" section.
4. Visit: `https://<your-github-username>.github.io/<repository-name>/`
